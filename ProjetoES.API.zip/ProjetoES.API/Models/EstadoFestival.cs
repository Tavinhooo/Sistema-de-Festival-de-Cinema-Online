namespace ProjetoES.Models
{
    public enum EstadoFestival
    {
        Futuro,
        Ativo,
        Cancelado,
        Arquivado
    }
}